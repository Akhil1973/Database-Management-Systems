/* This is a skeleton code for Optimized Merge Sort, you can make modifications as long as you meet 
   all question requirements*/  

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <math.h>
#include <iterator> 
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <type_traits> 
#include <bits/stdc++.h>
#include "record_class.h"

using namespace std;

//defines how many blocks are available in the Main Memory 
#define buffer_size 22

Records buffers[buffer_size]; //use this class object of size 22 as your main memory

/***You can change return type and arguments as you want.***/

//Sorting the buffers in main_memory and storing the sorted records into a temporary file (runs) 
void Sort_Buffer(){
    //Remember: You can use only [AT MOST] 22 blocks for sorting the records / tuples and create the runs
    
	return;
}

//Prints out the attributes from empRecord and deptRecord when a join condition is met 
//and puts it in file Join.csv
void PrintJoin(vector<Records> emplist, vector<Records> deptlist, std::fstream& join) {
	
	
	//cout<< "called"<<endl;
	for(int i=0; i<deptlist.size();i++){
		//cout << deptlist.at(i).dept_record.did <<endl;
		cout << deptlist.at(i).dept_record.did << "," << deptlist.at(i).dept_record.dname << "," << deptlist.at(i).dept_record.budget << ","<<deptlist.at(i).dept_record.managerid <<","<< emplist.at(i).emp_record.eid <<","<< emplist.at(i).emp_record.ename<<","<< emplist.at(i).emp_record.age  << ","<< emplist.at(i).emp_record.salary <<"\n";
		join << deptlist.at(i).dept_record.did << "," << deptlist.at(i).dept_record.dname << "," << deptlist.at(i).dept_record.budget << ","<<deptlist.at(i).dept_record.managerid <<","<< emplist.at(i).emp_record.eid <<","<< emplist.at(i).emp_record.ename<<","<< emplist.at(i).emp_record.age  << ","<< emplist.at(i).emp_record.salary <<"\n";
	}
	
    
    return;
}

//Use main memory to Merge and Join tuples 
//which are already sorted in 'runs' of the relations Dept and Emp 
void Merge_Join_Runs(std::fstream& dept, std::fstream& emp, std::fstream& join){
	
	
	emp.open("EmpSorted.csv", ios::in);
    dept.open("DeptSorted.csv", ios::in);	
	join.open("join.csv", ios::out | ios::app);
      Records deptBlock,empBlock;
	  vector<Records> emplist;
	 vector<Records> deptlist;
	 int i=0;
	  string line;
	  while(1){
		  
		  if(dept.eof()){	
		 PrintJoin(emplist,deptlist,join);
			  break;
		  }
			  
	  deptBlock = Grab_Dept_Record(dept);	  
	  empBlock = Grab_Emp_Record(emp); 
	  emplist.push_back(empBlock);
	  deptlist.push_back(deptBlock);
	  
	  
		  
	  dept.peek();
	  i++;
	  if(i>buffer_size/2){
		  
	  PrintJoin(emplist,deptlist,join);
	  emplist.clear();
	 deptlist.clear();
	  i=0;
	  
	  }
	  
	  //emp.peek();
	  
	  }
   

    //and store the Joined new tuples using PrintJoin() 
    return;
}

bool compareByManagerid(Records a, Records b)
{
  
  return (a.dept_record.managerid < b.dept_record.managerid);
	
}


bool compareByEid(Records a, Records b)
{
  
  return (a.emp_record.eid < b.emp_record.eid);
	
}

void cleanUpTemp(std::string dept, std::string emp){
	
	
	if(remove(dept.c_str()) == 0)
		{
			//cout << "temp dept file removed" << endl;
		}
		
		if(remove(emp.c_str()) == 0)
		{
			//cout << "temp emp file removed" << endl;
		}
		
	
}


int main() {

    //Open file streams to read and write
    //Opening out two relations Emp.csv and Dept.csv which we want to join
	int i=0;
	int j=0;
	//int dept_count=0;
    fstream empin;
    fstream deptin;
	fstream depttemp;
	fstream emptemp;	
	empin.open("Emp.csv", ios::in);
    deptin.open("Dept.csv", ios::in);	
    
	string temp1= "DeptSorted.csv";
	string temp2="EmpSorted.csv";
   depttemp.open(temp1, ios::out | ios::app);	
    emptemp.open(temp2, ios::out | ios::app);
    //Creating the Join.csv file where we will store our joined results
    fstream joinout;
    //joinout.open("Join.csv", ios::out | ios::app);
		
      Records deptBlock,empBlock;
	 vector<Records> emplist;
	 vector<Records> deptlist;
	 vector<int> mid;
	 // adding all dept records into the vector..
	 while(!deptin.eof()&& i<=buffer_size-1){
		 
	  deptBlock = Grab_Dept_Record(deptin); 
	  deptin.peek();    
      deptlist.push_back(deptBlock);
  
      //cout<< i <<" "<< deptBlock.dept_record.managerid <<"\n";
	  i++;
    }	
	
   sort(deptlist.begin(), deptlist.end(), compareByManagerid);
   //cout<< "dept"<<endl;
   
   for(int i=0; i<=deptlist.size();i++){
	if(i==deptlist.size()){
		deptlist.clear();
		break;		
	}
	
	//cout<< i <<" "<< deptlist.at(i).dept_record.managerid <<"\n";
	mid.push_back(deptlist.at(i).dept_record.managerid);
	depttemp << deptlist.at(i).dept_record.did <<','<< deptlist.at(i).dept_record.dname <<','<< deptlist.at(i).dept_record.budget <<','<< deptlist.at(i).dept_record.managerid <<endl;
	}
   
   
   	
   while(!empin.eof()&&j<=buffer_size-1){
		 
	  empBlock = Grab_Emp_Record(empin); 
	  empin.peek();    
	  for(int i=0; i<mid.size();i++){
		  if(empBlock.emp_record.eid == mid.at(i)){
			 emplist.push_back(empBlock);
			 //mid.erase(i);
			 mid.at(i)=-1;			 
			 j++;
			 
		  }
	  }
  
   }
   
	  
	  
   sort(emplist.begin(), emplist.end(), compareByEid);
   //cout<< "emp"<<endl;
   for(int i=0; i<emplist.size();i++){
   //cout<< i <<" "<< emplist.at(i).emp_record.eid <<"\n";
   emptemp << emplist.at(i).emp_record.eid <<','<< emplist.at(i).emp_record.ename <<','<< emplist.at(i).emp_record.age <<','<< emplist.at(i).emp_record.salary <<endl;
		
	}
	
	emplist.clear();
	
	depttemp.close();
	
	emptemp.close();
	Merge_Join_Runs(depttemp,emptemp,joinout);
	
	cleanUpTemp(temp1,temp2);
	
	   
	   
	   
	   
	   
	   
 

    //1. Create runs for Dept and Emp which are sorted using Sort_Buffer()


    //2. Use Merge_Join_Runs() to Join the runs of Dept and Emp relations 


    //Please delete the temporary files (runs) after you've joined both Emp.csv and Dept.csv

    return 0;
}
