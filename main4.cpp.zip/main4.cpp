/* This is a skeleton code for two-pass multi-way sorting, you can make modifications as long as you meet
all question requirements*/
//Currently this program will just load the records in the buffers (main memory) and print them when filled up.
//And continue this process untill the full Emp.csv is read.



#include <bits/stdc++.h>
#include <stdio.h>
#include <vector>
using namespace std;



//defines how many buffers are available in the Main Memory
#define buffer_size 22




struct EmpRecord {
int eid;
string ename;
int age;
double salary;
};
EmpRecord buffers[buffer_size],temp; // this structure contains 22 buffers; available as your main memory.



// Grab a single block from the Emp.csv file, in theory if a block was larger than
// one tuple, this function would return an array of EmpRecords and the entire if
// and else statement would be wrapped in a loop for x times based on block size
EmpRecord Grab_Emp_Record(fstream &empin) {
string line, word;
EmpRecord emp;
// grab entire line
if (getline(empin, line, '\n')) {
// turn line into a stream
stringstream s(line);
// gets everything in stream up to comma
getline(s, word,',');
emp.eid = stoi(word);
getline(s, word, ',');
emp.ename = word;
getline(s, word, ',');
emp.age = stoi(word);
getline(s, word, ',');
emp.salary = stod(word);
return emp;
} else {
emp.eid = -1;
return emp;
}
}



//Printing whatever is stored in the buffers of Main Memory
//Can come in handy to see if you've sorted the records in your main memory properly.
void Print_Buffers(int cur_size) {
for (int i = 0; i < cur_size; i++)
{
cout << i << " " << buffers[i].eid << " " << buffers[i].ename << " " << buffers[i].age << " " << buffers[i].salary << endl;
}
}



//Sorting the buffers in main_memory based on 'eid' and storing the sorted records into a temporary file
//You can change return type and arguments as you want.
void Sort_in_Main_Memory(EmpRecord buffers[], int length, int p){



stringstream a;
a << p;
string fname= "sorted" +a.str();
fstream tempf;
tempf.open(fname+".csv", ios::out | ios::app);
//int temp1;
//string temp2;
//int temp3;
//double temp4;

//int t_arr[buffer_size];

//for(int i=0;i<length;i++)
//t_arr[i] << (int) buffers[i].eid;

//sort(t_arr, t_arr+length);
for(int i=0;i<length-1;i++){
//temp1=0;
//temp2= '\0';
//temp3=0;
//temp4=0;
for( int j=0;j<length-i-1;j++){
if(buffers[j].eid > buffers[j+1].eid)
{
// temp1=buffers[j].eid;
// buffers[j].eid = buffers[j+1].eid;
// buffers[j+1].eid=temp1;

// temp2=buffers[j].ename;
// buffers[j].ename = buffers[j+1].ename;
// buffers[j+1].ename=temp2;

// temp3=buffers[j].age;
// buffers[j].age = buffers[j+1].age;
// buffers[j+1].age=temp3;

// temp4=buffers[j].salary;
// buffers[j].salary = buffers[j+1].salary;
// buffers[j+1].salary=temp4;

swap(buffers[j],buffers[j+1]);

}

}
}


for(int i=0;i<length;i++)
tempf << buffers[i].eid <<"," << buffers[i].ename << "," << buffers[i].age << "," << buffers[i].salary << "\n";

tempf.close();
cout << fname << endl;
//EmpRecord s_EmpRecord = Grab_Emp_Record(tempf);
//tempf.open(fname, ios::in);



//cout << "Sorting Not Implemented" << endl;
return;
}



void swap( EmpRecord buffer1, EmpRecord buffer2 )
{
temp = buffer1;
buffer1=buffer2;
buffer2=temp;
}



bool compare(const tuple<int, EmpRecord>& a, const tuple<int, EmpRecord>& b)
{
return get<1>(a).eid < get<1>(b).eid;
}




//You can use this function to merge your M-1 runs using the buffers in main memory and storing them in sorted file 'EmpSorted.csv'(Final Output File)
//You can change return type and arguments as you want.
void Merge_Runs_in_Main_Memory(int p){


fstream sorted_file;
string filename = "EmpSorted.csv";
sorted_file.open(filename, ios::out | ios::app);

fstream arr[p];
string input_file;
for(int i = 0; i< p; i++)
{
input_file = "sorted"+to_string(i)+".csv";
arr[i].open(input_file, ios::in);
}
int cur_size=0;
int y=0;
int x=0;

vector<tuple<int, EmpRecord>> buffer;
EmpRecord single_EmpRecord;

for(int i=0; i<buffer_size-1; i++)
{
if(x >= p)
{
x = 0;
}
single_EmpRecord = Grab_Emp_Record(arr[x]);
buffer.push_back(make_tuple(x, single_EmpRecord));
x++;
}

bool flag = true;
while(flag){

std::sort(buffer.begin(), buffer.end(),compare);

sorted_file << std::fixed << get<1>(buffer[0]).eid << ',' << get<1>(buffer[0]).ename << ',' << get<1>(buffer[0]).age << ',' << std::setprecision(0) << get<1>(buffer[0]).salary << "\n";

EmpRecord single_EmpRecord = Grab_Emp_Record(arr[get<0>(buffer[0])]);
y = 0;
x = get<0>(buffer[0]);

while(single_EmpRecord.eid == -1 && y < p)
{ 
x++;
if(x >= p)
{
x = 0;
}
y++;
single_EmpRecord = Grab_Emp_Record(arr[x]);
}
if(y == p)
{

flag = false;

for(int i=0; i<p; i++)
{
arr[i].close();
}
}
else
{
buffer[0] = make_tuple(x, single_EmpRecord);
}
}
cout << "All blocks read into buffer" << endl;
for(int i=1; i < buffer_size-1; i++)
{
sorted_file << std::fixed << get<1>(buffer[i]).eid << ',' << get<1>(buffer[i]).ename << ',' << get<1>(buffer[i]).age << ',' << std::setprecision(0) << get<1>(buffer[i]).salary << "\n";
}




sorted_file.close();
//cout << "Merging Not Implemented" << endl;
}

int main() {
// open file streams to read and write
fstream input_file;
input_file.open("Emp.csv", ios::in);
//input_file.seekg(0,ios::end);
//int size= input_file.tellg();
// flags check when relations are done being read
bool flag = true;
int cur_size = 0;
int p=0;


/*First Pass: The following loop will read each block put it into main_memory
and sort them then will put them into a temporary file for 2nd pass */
while (flag) {
// FOR BLOCK IN RELATION EMP



// grabs a block
EmpRecord single_EmpRecord = Grab_Emp_Record(input_file);
// checks if filestream is empty
if (single_EmpRecord.eid == -1) {
flag = false;
//Print_Buffers(cur_size); // The main_memory is not filled up but there are some leftover data that needs to be sorted.
Sort_in_Main_Memory(buffers,cur_size,p);
p++;
}
if(cur_size + 1 <= buffer_size){
//Memory is not full store current record into buffers.
buffers[cur_size] = single_EmpRecord ;
cur_size += 1;
}
else{
//memory is full now. Sort the blocks in Main Memory and Store it in a temporary file (runs)
//cout << "Main Memory is full. Time to sort and store sorted blocks in a temporary file" << endl;
//Print_Buffers(buffer_size);
Sort_in_Main_Memory(buffers,cur_size,p);
p++;
//Print_Buffers(buffer_size);
// sorting


//SortMain("Attributes You Want");

//After sorting start again. Clearing memory and putting the current one into main memory.
cur_size = 0;
buffers[cur_size] = single_EmpRecord;
cur_size += 1;
//p+=1;
}

}
input_file.close();
//Merge_Runs_in_Main_Memory(p);
/* Implement 2nd Pass: Read the temporary sorted files and utilize main_memory to store sorted runs into the EmpSorted.csv*/



//Uncomment when you are ready to store the sorted relation
//fstream sorted_file;
//sorted_file.open("EmpSorted.csv", ios::out | ios::app);



//Pseudocode
//bool flag_sorting_done = false;
//q=p-1;
// while(!flag_sorting_done){

Merge_Runs_in_Main_Memory(p);
//break;
//}

//You can delete the temporary sorted files (runs) after you're done if you want. It's okay if you don't.



return 0;
}