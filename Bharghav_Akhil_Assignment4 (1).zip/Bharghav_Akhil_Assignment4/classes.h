#include <vector>
#include <math.h>
#include <map>
#include <iterator> 
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <string>
#include <cstring>
#include <iostream>
using namespace std;

class Record {
public:
    int id, manager_id;
    std::string bio, name;

    Record(vector<std::string> fields) {
        id = stoi(fields[0]);
        name = fields[1];
        bio = fields[2];
        manager_id = stoi(fields[3]);
    }

    void print() {
        cout << "\tID: " << id << "\n";
        cout << "\tNAME: " << name << "\n";
        cout << "\tBIO: " << bio << "\n";
        cout << "\tMANAGER_ID: " << manager_id << "\n";
    }
};

struct Block {
    int index;
    vector<Record> RecordBlock;
    int hashvalue;
    struct Block *next;
};

vector<Record> Recorddata; 
map<int,Block * > blockMap;
map<int,int> searchMap;
int globalIndex = 1;
int maxIndex = 1;
int nextpt = 0;
int recordCount = 0;
int n=1;
int rd=0;


int getid;
int getmanagerid;
string getname;
string getbio;
int split=0;
int res;
int attempt;
int c=0;
int s=0;
void insertHash(); 
bool lookuprecord(int index);

void searchIndex(int id);
//bool Lookup();
