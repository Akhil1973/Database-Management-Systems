#include "classes.h"

int main(int argc, char* argv[])
{
  
fstream inputFile;
inputFile.open("Employee.csv",ios::in);
//vector<Record> records;
vector<std::string> buffer;

string str,element;
if(inputFile.is_open()){
	while(getline(inputFile,str)){
		stringstream strStream(str);
                buffer.clear();
				// inserting 10 records and then calling the  hash function indexing.
                if(s<10){
				
                while(getline(strStream, element, ','))
                    buffer.push_back(element);
				
				Record a(buffer);
				Recorddata.push_back(a);
				s++;
				}
				
				else if(s>=10){
					s=0;
					insertHash();
					Recorddata.clear();
					buffer.clear();
				}
				
				
					
		
	}
}

    

    if(argc > 1 && argc <= 10) {
         
        if(strcmp(argv[1], "L") == 0) {
            cout << "Lookup!!\n";
            getid = stoi(argv[2]);
			//cout << getid << endl;
            searchIndex(getid);
        }
        
        
    }

    
}

int hashingFunct(int id, int i) 
{   
    int div = pow(2, 16);
	div=id%div;
	int div1;
    if(i>=0){
		div1 = pow(2,i);
		}
		
    return  div % div1;
}

//int hashingFunction(int id){
	//int d = pow(2,16);
	//return id%d;
//}

int Overflow(int k,int l) 
{
  if(blockMap.size()<=k)
  {k=l;}
  int usage = (blockMap[k]->RecordBlock.size());
  return usage > 5;
}

void print_Index()
{	
    ofstream OP_file;
    OP_file.open("EmployeeIndex.txt",ios::app);
    for (int i = 0; i < blockMap.size() ; i++)
    {	c++;
        OP_file <<"|"<<"i:"<< c << endl;
        for(int j= 0; j< blockMap[i]->RecordBlock.size(); j++) {
            OP_file << blockMap[i]->RecordBlock[j].id << ',';
            OP_file << blockMap[i]->RecordBlock[j].name << ',';
			OP_file << blockMap[i]->RecordBlock[j].bio <<',';
            OP_file << blockMap[i]->RecordBlock[j].manager_id << '\n';
			searchMap.insert({c, blockMap[i]->RecordBlock[j].id});
			   for (auto itr = searchMap.begin(); itr != searchMap.end(); ++itr) {
				cout << itr->first<< '\t' << itr->second << '\n';
    }
            if(blockMap[i]->next!=NULL && j==blockMap[i]->RecordBlock.size()-1)
            {
				cout<<"overflow block:";blockMap[i]=blockMap[i]->next;j=0;}
		}
            OP_file << '\n';
			
    }
	
    OP_file.close();
	blockMap.clear();
}



void insertHash() 
{ int bs=blockMap.size();
    if(bs == 0) {
        blockMap[0] = new Block;
        blockMap[1] = new Block;
        blockMap[1]->next=NULL;
        blockMap[0]->next=NULL;
        blockMap[0]->hashvalue=2;
        blockMap[1]->hashvalue=2;
        nextpt=0;
    }
  int j=0;
 
    for(int i=0;i<Recorddata.size();i++) {
        recordCount = i+1;
        int indexNumber = hashingFunct(Recorddata[i].id, rd);
        int u;
        u=blockMap[indexNumber]->hashvalue;
          int e;
          e=Recorddata[i].id%u;
        
        if(!Overflow(e,indexNumber)) {
          
          if(e>=blockMap.size())
            {
              e=indexNumber;
            }
            Block* matchedBlock = blockMap[e];
            
            Record empTmp = Recorddata[i];

            if(matchedBlock->index == 0) {
                matchedBlock->index = globalIndex;
            }
          
            matchedBlock->RecordBlock.push_back(empTmp);
            
        } else {
         
          Block * flow=blockMap[indexNumber]->next;
          ;
          Record empTmp = Recorddata[i];
          n=n+1;
          blockMap[n]= new Block;
          blockMap[n]->next=NULL;
          
          int l=log2 (blockMap[nextpt]->hashvalue);
          
          int y;
          y=blockMap[nextpt]->RecordBlock.size();
          int r;
          for(int j= 0; j< y; j++) {
           int k= blockMap[nextpt]->RecordBlock[0].id;
           
           
           r=hashingFunct(k,l);
           indexNumber=hashingFunct(k, l+1);
          
            
            if(indexNumber>=blockMap.size())
            {
              indexNumber=r;
            }
            
            
           Block * mBlock=blockMap[indexNumber];
           mBlock->RecordBlock.push_back(blockMap[nextpt]->RecordBlock[0]);
           
           blockMap[nextpt]->RecordBlock.erase(blockMap[nextpt]->RecordBlock.begin());
           if(j==y-1 && blockMap[nextpt]->next!=NULL)
           {
             j=0;
             blockMap[nextpt]=flow;
           }
           
        }
        blockMap[nextpt]->hashvalue=pow(2,l+1);
        blockMap[n]->hashvalue=pow(2,l+1);
          if(nextpt<= pow (2,rd+1)-1)
          {
            nextpt=nextpt+1;
          }
          if(nextpt>pow(2,rd+1)-1)
          {
            nextpt=0;
            rd=rd+1;
            
          }
          
        }
    }
    print_Index();
	//blockMap.clear();
	
    
}



void searchIndex(int id){
	int l=0;
	//cout << "id is here" << endl;
	 for (auto& it : searchMap) {
		l++;
        // If mapped value is K,
        // then print the key value
        if (it.second == id) {
            cout << "The index for the id:  "<< id << " is " << it.first << endl;
           break;
        }
		 if(l+1 >searchMap.size()){
			cout << "Invalid id" << endl;
           
		}
		
    }
}


